package team07.comp3710.csse.eng.auburn.edu.roommatewrangler;

/**
 * Created by Margaret Caufield on 4/19/2015.
 */

public enum BillType {
    WATER,
    POWER,
    INTERNET_CABLE,
    TRASH,
    LANDSCAPING
}
