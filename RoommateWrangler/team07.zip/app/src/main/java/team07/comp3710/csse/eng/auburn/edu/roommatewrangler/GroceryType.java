package team07.comp3710.csse.eng.auburn.edu.roommatewrangler;

/**
 * Created by Margaret Caufield on 4/19/2015.
 */

public enum GroceryType {
    BREAD,
    MILK,
    EGGS,
    FAST_FOOD_PIZZA
}
